# 스타크래프트 정보 출처 및 데이터 내보내기

작성: 2026-11-05

## 범위
프로젝트 파일과 보관된 조사·검증 기록에서 확인한 출처를 아래에 모두 모았습니다. 보조 조회와 실제 적용 근거를 구분했습니다. 기록에 남지 않은 검색 결과까지 완전하게 복원한 목록이라는 뜻은 아닙니다.

- `starcraft-applied-data.json`: 실제 적용된 저그 8종 비용·인구수·시간, 표시 HP, 채취 9덩이 평균, 출처, 별도 가정값.
- `starcraft-research.json`: 기존 3종족 조사 자료 전체와 당시 검증 보고서. 게임에 직접 로드하지 않았던 추가 자료입니다.
- `validation-report.json`: 이번 로컬 대조 결과 및 원자료 SHA-256.
- `simulation-tests.txt`: 이번에 다시 실행한 시뮬레이션 테스트 결과.

## 검증 해석
비용과 인구수는 고정 BWAPI 자료와 대조했습니다. 생산 시간은 적용값과 원자료 프레임 환산값을 나란히 보존했습니다. 가스 초당 0.7, 라바 14초, 명령 대기 4프레임, 최초 출발 지연, 화면 좌표 등은 원작 검증값으로 분류하지 않았습니다.

채취 평균은 공개 실험에 기반하며, 투혼 네 시작 위치를 직접 측정한 결과가 아닙니다. OpenBW는 비공식 엔진 재구현입니다. BWAPI는 고정 커밋을 사용했으나 OpenBW는 당시 master 다운로드이며 커밋은 기록되지 않아 로컬 해시를 제공합니다.

기존 3종족 검증 보고서는 과거 기록으로 보존했습니다. 테란 7건, 프로토스 3건의 구형 공식 페이지와 BWAPI 차이는 원본 데이터의 official_source_discrepancies에 남아 있습니다. 검사 통과는 공식 페이지의 모든 숫자와 일치한다는 뜻이 아닙니다.

## 출처 목록

### source-001
- URL: <https://github.com/bwapi/bwapi/blob/d727fed68558c506163048ea889131d8cbb33915/bwapi/BWAPILIB/Source/UnitType.cpp>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#bwapi-unit; research/starcraft-terran/terran-data.json#bwapi-unit; research/starcraft-protoss/protoss-data.json#bwapi-unit

### source-002
- URL: <https://github.com/bwapi/bwapi/blob/d727fed68558c506163048ea889131d8cbb33915/bwapi/BWAPILIB/Source/WeaponType.cpp>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#bwapi-weapon; research/starcraft-terran/terran-data.json#bwapi-weapon; research/starcraft-protoss/protoss-data.json#bwapi-weapon

### source-003
- URL: <https://github.com/bwapi/bwapi/blob/d727fed68558c506163048ea889131d8cbb33915/bwapi/BWAPILIB/Source/UpgradeType.cpp>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#bwapi-upgrade; research/starcraft-terran/terran-data.json#bwapi-upgrade; research/starcraft-protoss/protoss-data.json#bwapi-upgrade

### source-004
- URL: <https://github.com/bwapi/bwapi/blob/d727fed68558c506163048ea889131d8cbb33915/bwapi/BWAPILIB/Source/TechType.cpp>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#bwapi-tech; research/starcraft-terran/terran-data.json#bwapi-tech; research/starcraft-protoss/protoss-data.json#bwapi-tech

### source-005
- URL: <https://classic.battle.net/scc/zerg/special.shtml>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#blizzard-special

### source-006
- URL: <https://classic.battle.net/scc/zerg/units/>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#blizzard-units

### source-007
- URL: <https://bwapi.github.io/class_b_w_a_p_i_1_1_unit_type.html>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#bwapi-doc; research/starcraft-terran/terran-data.json#bwapi-doc; research/starcraft-protoss/protoss-data.json#bwapi-doc

### source-008
- URL: <https://classic.battle.net/scc/zerg/popup/hive.htm>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-zerg/zerg-data.json#blizzard-hive

### source-009
- URL: <https://classic.battle.net/scc/zerg/units/larva.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-010
- URL: <https://classic.battle.net/scc/zerg/units/drone.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-011
- URL: <https://classic.battle.net/scc/zerg/units/overlord.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-012
- URL: <https://classic.battle.net/scc/zerg/units/zergling.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-013
- URL: <https://classic.battle.net/scc/zerg/units/hydralisk.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-014
- URL: <https://classic.battle.net/scc/zerg/units/mutalisk.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-015
- URL: <https://classic.battle.net/scc/zerg/units/scourge.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-016
- URL: <https://classic.battle.net/scc/zerg/units/queen.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-017
- URL: <https://classic.battle.net/scc/zerg/units/lurker.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-018
- URL: <https://classic.battle.net/scc/zerg/units/defiler.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-019
- URL: <https://classic.battle.net/scc/zerg/units/ultralisk.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-020
- URL: <https://classic.battle.net/scc/zerg/units/guardian.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-021
- URL: <https://classic.battle.net/scc/zerg/units/devourer.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-022
- URL: <https://classic.battle.net/scc/zerg/units/broodling.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-023
- URL: <https://classic.battle.net/scc/zerg/units/iterran.shtml>
- 용도: 공식 페이지 과거 대조
- 기록: research/starcraft-zerg/validation-report.json

### source-024
- URL: <https://classic.battle.net/scc/terran/unit.shtml>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-terran/terran-data.json#blizzard-units

### source-025
- URL: <https://classic.battle.net/scc/terran/tspecial.shtml>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-terran/terran-data.json#blizzard-special

### source-026
- URL: <https://classic.battle.net/scc/terran/uscv.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_scv; research/starcraft-terran/validation-report.json

### source-027
- URL: <https://classic.battle.net/scc/terran/um.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_marine; research/starcraft-terran/validation-report.json

### source-028
- URL: <https://classic.battle.net/scc/terran/ufire.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_firebat; research/starcraft-terran/validation-report.json

### source-029
- URL: <https://classic.battle.net/scc/terran/ug.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_ghost; research/starcraft-terran/validation-report.json

### source-030
- URL: <https://classic.battle.net/scc/terran/uv.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_vulture; research/starcraft-terran/validation-report.json

### source-031
- URL: <https://classic.battle.net/scc/terran/ut.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_siege_tank_tank_mode; research/starcraft-terran/validation-report.json

### source-032
- URL: <https://classic.battle.net/scc/terran/ugl.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_goliath; research/starcraft-terran/validation-report.json

### source-033
- URL: <https://classic.battle.net/scc/terran/uw.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_wraith; research/starcraft-terran/validation-report.json

### source-034
- URL: <https://classic.battle.net/scc/terran/ud.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_dropship; research/starcraft-terran/validation-report.json

### source-035
- URL: <https://classic.battle.net/scc/terran/ub.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_battlecruiser; research/starcraft-terran/validation-report.json

### source-036
- URL: <https://classic.battle.net/scc/terran/us.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_science_vessel; research/starcraft-terran/validation-report.json

### source-037
- URL: <https://classic.battle.net/scc/terran/umedic.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_medic; research/starcraft-terran/validation-report.json

### source-038
- URL: <https://classic.battle.net/scc/terran/uvalkyrie.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_valkyrie; research/starcraft-terran/validation-report.json

### source-039
- URL: <https://classic.battle.net/scc/popup/sd.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_supply_depot; research/starcraft-terran/validation-report.json

### source-040
- URL: <https://classic.battle.net/scc/popup/cc.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_command_center; research/starcraft-terran/validation-report.json

### source-041
- URL: <https://classic.battle.net/scc/popup/comm.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_comsat_station; research/starcraft-terran/validation-report.json

### source-042
- URL: <https://classic.battle.net/scc/popup/silo.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_nuclear_silo; research/starcraft-terran/validation-report.json

### source-043
- URL: <https://classic.battle.net/scc/popup/bay.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_engineering_bay; research/starcraft-terran/validation-report.json

### source-044
- URL: <https://classic.battle.net/scc/popup/barx.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_barracks; research/starcraft-terran/validation-report.json

### source-045
- URL: <https://classic.battle.net/scc/popup/refin.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_refinery; research/starcraft-terran/validation-report.json

### source-046
- URL: <https://classic.battle.net/scc/popup/turt.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_missile_turret; research/starcraft-terran/validation-report.json

### source-047
- URL: <https://classic.battle.net/scc/popup/acad.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_academy; research/starcraft-terran/validation-report.json

### source-048
- URL: <https://classic.battle.net/scc/popup/bunk.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_bunker; research/starcraft-terran/validation-report.json

### source-049
- URL: <https://classic.battle.net/scc/popup/fact.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_factory; research/starcraft-terran/validation-report.json

### source-050
- URL: <https://classic.battle.net/scc/popup/mshp.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_machine_shop; research/starcraft-terran/validation-report.json

### source-051
- URL: <https://classic.battle.net/scc/popup/arm.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_armory; research/starcraft-terran/validation-report.json

### source-052
- URL: <https://classic.battle.net/scc/popup/star.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_starport; research/starcraft-terran/validation-report.json

### source-053
- URL: <https://classic.battle.net/scc/popup/ctwr.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_control_tower; research/starcraft-terran/validation-report.json

### source-054
- URL: <https://classic.battle.net/scc/popup/scif.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_science_facility; research/starcraft-terran/validation-report.json

### source-055
- URL: <https://classic.battle.net/scc/popup/plab.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_physics_lab; research/starcraft-terran/validation-report.json

### source-056
- URL: <https://classic.battle.net/scc/popup/cops.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-terran/terran-data.json#blizzard-terran_covert_ops; research/starcraft-terran/validation-report.json

### source-057
- URL: <https://classic.battle.net/scc/protoss/units/>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-units

### source-058
- URL: <https://classic.battle.net/scc/protoss/special.shtml>
- 용도: 조사 데이터 원자료
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-special

### source-059
- URL: <https://classic.battle.net/scc/protoss/units/probe.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_probe; research/starcraft-protoss/validation-report.json

### source-060
- URL: <https://classic.battle.net/scc/protoss/units/zealot.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_zealot; research/starcraft-protoss/validation-report.json

### source-061
- URL: <https://classic.battle.net/scc/protoss/units/dragoon.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_dragoon; research/starcraft-protoss/validation-report.json

### source-062
- URL: <https://classic.battle.net/scc/protoss/units/templar.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_high_templar; research/starcraft-protoss/validation-report.json

### source-063
- URL: <https://classic.battle.net/scc/protoss/units/darktemplar.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_dark_templar; research/starcraft-protoss/validation-report.json

### source-064
- URL: <https://classic.battle.net/scc/protoss/units/shuttle.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_shuttle; research/starcraft-protoss/validation-report.json

### source-065
- URL: <https://classic.battle.net/scc/protoss/units/reaver.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_reaver; research/starcraft-protoss/validation-report.json

### source-066
- URL: <https://classic.battle.net/scc/protoss/units/observer.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_observer; research/starcraft-protoss/validation-report.json

### source-067
- URL: <https://classic.battle.net/scc/protoss/units/scout.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_scout; research/starcraft-protoss/validation-report.json

### source-068
- URL: <https://classic.battle.net/scc/protoss/units/corsair.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_corsair; research/starcraft-protoss/validation-report.json

### source-069
- URL: <https://classic.battle.net/scc/protoss/units/carrier.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_carrier; research/starcraft-protoss/validation-report.json

### source-070
- URL: <https://classic.battle.net/scc/protoss/units/arbiter.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_arbiter; research/starcraft-protoss/validation-report.json

### source-071
- URL: <https://classic.battle.net/scc/protoss/units/archon.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_archon; research/starcraft-protoss/validation-report.json

### source-072
- URL: <https://classic.battle.net/scc/protoss/units/darkarchon.shtml>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_dark_archon; research/starcraft-protoss/validation-report.json

### source-073
- URL: <https://classic.battle.net/scc/protoss/popup/assimilator.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_assimilator; research/starcraft-protoss/validation-report.json

### source-074
- URL: <https://classic.battle.net/scc/protoss/popup/nexus.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_nexus; research/starcraft-protoss/validation-report.json

### source-075
- URL: <https://classic.battle.net/scc/protoss/popup/pylon.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_pylon; research/starcraft-protoss/validation-report.json

### source-076
- URL: <https://classic.battle.net/scc/protoss/popup/gateway.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_gateway; research/starcraft-protoss/validation-report.json

### source-077
- URL: <https://classic.battle.net/scc/protoss/popup/forge.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_forge; research/starcraft-protoss/validation-report.json

### source-078
- URL: <https://classic.battle.net/scc/protoss/popup/battery.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_shield_battery; research/starcraft-protoss/validation-report.json

### source-079
- URL: <https://classic.battle.net/scc/protoss/popup/cybercore.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_cybernetics_core; research/starcraft-protoss/validation-report.json

### source-080
- URL: <https://classic.battle.net/scc/protoss/popup/photon.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_photon_cannon; research/starcraft-protoss/validation-report.json

### source-081
- URL: <https://classic.battle.net/scc/protoss/popup/robotics.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_robotics_facility; research/starcraft-protoss/validation-report.json

### source-082
- URL: <https://classic.battle.net/scc/protoss/popup/stargate.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_stargate; research/starcraft-protoss/validation-report.json

### source-083
- URL: <https://classic.battle.net/scc/protoss/popup/citadel.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_citadel_of_adun; research/starcraft-protoss/validation-report.json

### source-084
- URL: <https://classic.battle.net/scc/protoss/popup/support.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_robotics_support_bay; research/starcraft-protoss/validation-report.json

### source-085
- URL: <https://classic.battle.net/scc/protoss/popup/beacon.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_fleet_beacon; research/starcraft-protoss/validation-report.json

### source-086
- URL: <https://classic.battle.net/scc/protoss/popup/archives.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_templar_archives; research/starcraft-protoss/validation-report.json

### source-087
- URL: <https://classic.battle.net/scc/protoss/popup/observatory.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_observatory; research/starcraft-protoss/validation-report.json

### source-088
- URL: <https://classic.battle.net/scc/protoss/popup/tribunal.htm>
- 용도: 조사 데이터 원자료 / 공식 페이지 과거 대조
- 기록: research/starcraft-protoss/protoss-data.json#blizzard-protoss_arbiter_tribunal; research/starcraft-protoss/validation-report.json

### source-089
- URL: <https://tl.net/forum/bw-strategy/612417-fighting-spirit-mining-rates?page=5>
- 용도: 채취 주기 적용: iopq #81–84
- 기록: docs/mining-model.md

### source-090
- URL: <https://tl.net/forum/bw-strategy/612417-fighting-spirit-mining-rates>
- 용도: 배치 대응 설명: TT1 #14
- 기록: docs/mining-model.md

### source-091
- URL: <https://github.com/OpenBW/openbw/blob/master/bwgame.h>
- 용도: 8 운반량·복귀 입금·75프레임 타이머 적용
- 기록: docs/mining-model.md

### source-092
- URL: <https://raw.githubusercontent.com/OpenBW/openbw/master/bwgame.h>
- 용도: OpenBW 다운로드 주소
- 기록: output/research/openbw-bwgame.h

### source-093
- URL: <https://i.ibb.co/VpsNFHD/PXL-20250128-171331118-MP.jpg>
- 용도: 실험 게시자의 프레임 기록 이미지
- 기록: output/research/right-patch-frames.jpg

### source-094
- URL: <https://scmscx.com/map/YrRGgVGR>
- 용도: 실험 맵 소개, 프로젝트에서 실행 검증하지 않음
- 기록: 채취 조사 기록

### source-095
- URL: <https://makingcomputerdothings.com/brood-war-api-the-comprehensive-guide-unit-movement-and-worker-behavios/>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-096
- URL: <https://broodwar.live/wiki/mechanics/resources/>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-097
- URL: <https://broodwar.live/wiki/mechanics/game-speed/>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-098
- URL: <https://liquipedia.net/starcraft/Drone>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-099
- URL: <https://liquipedia.net/starcraft/Game_Speed>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-100
- URL: <https://liquipedia.net/starcraft/Resources>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-101
- URL: <https://liquipedia.net/starcraft/Mutalisk>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

### source-102
- URL: <https://liquipedia.net/starcraft/Spire>
- 용도: 보조 조회; 적용값의 직접 검증 근거로 사용하지 않음
- 기록: 이전 구현 조사 기록

## 적용 근거에서 제외한 조회
다음은 빌드 검색용 조회였으며 검증된 빌드 데이터로 내보내지 않았습니다:
- <https://liquipedia.net/starcraft/Zerg_vs._Zerg_Guide>
- <https://liquipedia.net/starcraft/9_Pool_Speed_into_1_Hatch_Spire_(vs._Zerg)>
- <https://liquipedia.net/starcraft/13_Pool_Muta_(vs._Terran)>
- <https://liquipedia.net/starcraft/2_Hatch_Muta_(vs._Terran)>
- <https://liquipedia.net/starcraft/2_Hatch_Muta_(vs._Protoss)>

이전 조회에서 접근 실패한 아래 주소는 검증 근거가 아닙니다:
- <https://classic.battle.net/scc/zerg/buildings/spire.shtml>
- <https://classic.battle.net/scc/zerg/buildings/lair.shtml>

## 시각 자산
지형과 스프라이트는 ImageGen 생성물입니다. 원작 이미지 추출 데이터가 아닙니다. 프롬프트와 사용 파일은 `docs/visual-assets.md`에 보관되어 있습니다.

## 재생성
프로젝트에서 `python3 exports/export_data.py`를 실행하면 현재 코드와 보관 데이터로 다시 내보냅니다. export 날짜는 이 조사본의 고정 작성일입니다. 원본 게임 코드와 research 파일은 수정하지 않습니다.
